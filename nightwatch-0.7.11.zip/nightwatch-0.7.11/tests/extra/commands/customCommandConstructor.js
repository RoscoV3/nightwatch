function Command() {}
Command.prototype.command = function() {
  return this;
};

module.exports = Command;
