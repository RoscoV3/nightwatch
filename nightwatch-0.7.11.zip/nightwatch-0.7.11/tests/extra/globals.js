module.exports = {

  before : function() {
    console.log('before');
  },

  after : function() {
    console.log('after');
  }
};